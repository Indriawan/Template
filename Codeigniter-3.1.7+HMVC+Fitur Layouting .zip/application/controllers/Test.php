<?php
class Test extends MY_Controller
{
	public function index()
	{
		$this->render('test/index');
		$this->render('test/layout');
	}
	public function layout()
	{
		$this->render('test/layout');
	}
}