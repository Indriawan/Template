<div class="useLayout">
	<?php print $content?>
</div>