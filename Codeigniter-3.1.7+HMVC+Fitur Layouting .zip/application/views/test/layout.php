<?php
$data['content'] = "ooo";
$this->beginContent('test/testLayout',$data);
?>
File ini menggunakan metode layouting.
<?php
$this->endContent();